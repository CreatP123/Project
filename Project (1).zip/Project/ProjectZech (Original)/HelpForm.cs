﻿using System;

namespace ProjectZech
{
    internal class HelpForm
    {
        private string helpText;

        public HelpForm(string helpText)
        {
            this.helpText = helpText;
        }

        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}