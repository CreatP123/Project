﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace ProjectZech
{
    public partial class Form1 : Form
    {
        // Внутренний класс для хранения массива точек
        private class ArrayPoints
        {
            private int index = 0;
            private Point[] points;

            public ArrayPoints(int size)
            {
                if (size <= 0) size = 2;
                points = new Point[size];
            }

            public void SetPoint(int x, int y)
            {
                if (index >= points.Length)
                {
                    index = 0;
                }
                points[index] = new Point(x, y);
                index++;
            }

            public void ResetPoints()
            {
                index = 0;
            }

            public int GetCountPoints()
            {
                return index;
            }

            public Point[] GetPoints()
            {
                return points;
            }
        }

        // Поля
        private bool isLeftMouse = false;
        private bool isRightMouse = false;
        private bool isFillMode = false;
        private ArrayPoints arrayPoints = new ArrayPoints(2);
        private List<Bitmap> layers = new List<Bitmap>(); // Список слоев
        private int currentLayerIndex = 0; // Индекс текущего слоя
        private Bitmap map;
        private Graphics graphics;
        private Pen drawPen = new Pen(Color.Black, 3f);
        private Pen erasePen;
        private Stack<Bitmap> undoStack = new Stack<Bitmap>();
        private Stack<Bitmap> redoStack = new Stack<Bitmap>();
        public Point lastPoint { get; private set; }
        private bool isModified = false;

        public Form1()
        {
            InitializeComponent();
            this.Resize += Form1_Resize;
            this.KeyPreview = true;
            this.FormClosing += Form1_FormClosing;
            InitializeLayers(); // Убедитесь, что слои инициализированы
            SetSize(); // Затем устанавливаем размер
            SaveState();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isModified)
            {
                var result = MessageBox.Show("Вы хотите сохранить изменения перед закрытием?", "Сохранение",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    button2_Click(this, EventArgs.Empty);
                    // Если пользователь отменил сохранение, отменяем закрытие
                    if (isModified) e.Cancel = true;
                }
                else if (result == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
        }

        private void InitializeLayers()
        {
            // Инициализация начального слоя
            layers.Add(new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height));
            using (Graphics g = Graphics.FromImage(layers[0]))
            {
                g.Clear(pictureBox1.BackColor);
            }
            map = layers[currentLayerIndex];
            graphics = Graphics.FromImage(map);
            pictureBox1.Image = map;
            UpdateLayerList();
            InitializeComboBox();
        }

        private void SetSize()
        {
            if (pictureBox1.Width <= 0 || pictureBox1.Height <= 0) return;

            // Обновляем размеры всех слоев
            List<Bitmap> newLayers = new List<Bitmap>();
            foreach (Bitmap layer in layers)
            {
                if (layer != null)
                {
                    Bitmap newLayer = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
                    using (Graphics g = Graphics.FromImage(newLayer))
                    {
                        g.Clear(pictureBox1.BackColor);
                        g.DrawImage(layer, 0, 0, newLayer.Width, newLayer.Height);
                    }
                    newLayers.Add(newLayer);
                }
            }

            // Освобождаем старые ресурсы
            foreach (Bitmap layer in layers)
            {
                layer.Dispose();
            }
            layers = newLayers;
            if (layers.Count > 0)
            {
                map = layers[currentLayerIndex];
                graphics = Graphics.FromImage(map);
            }
            else
            {
                map = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
                graphics = Graphics.FromImage(map);
                graphics.Clear(pictureBox1.BackColor);
                layers.Add(map);
            }

            drawPen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            drawPen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            erasePen = new Pen(pictureBox1.BackColor, drawPen.Width);
            erasePen.StartCap = System.Drawing.Drawing2D.LineCap.Round;
            erasePen.EndCap = System.Drawing.Drawing2D.LineCap.Round;

            pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
            UpdatePictureBox();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (pictureBox1.ClientSize.Width > 0 && pictureBox1.ClientSize.Height > 0)
            {
                SetSize();
            }
        }

        private void SaveState()
        {
            Bitmap state = (Bitmap)map.Clone();
            undoStack.Push(state);
            redoStack.Clear();
            isModified = true;
        }

        private void Undo()
        {
            if (undoStack.Count > 1)
            {
                Bitmap current = undoStack.Pop();
                redoStack.Push(current);
                map = (Bitmap)undoStack.Peek().Clone();
                layers[currentLayerIndex] = map;
                graphics = Graphics.FromImage(map);
                UpdatePictureBox();
                isModified = true;
            }
        }

        private void Redo()
        {
            if (redoStack.Count > 0)
            {
                Bitmap state = redoStack.Pop();
                undoStack.Push(state);
                map = (Bitmap)state.Clone();
                layers[currentLayerIndex] = map;
                graphics = Graphics.FromImage(map);
                UpdatePictureBox();
                isModified = true;
            }
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.S:
                        button2_Click(this, EventArgs.Empty);
                        e.Handled = true;
                        break;
                    case Keys.Z:
                        Undo();
                        e.Handled = true;
                        break;
                    case Keys.Y:
                        Redo();
                        e.Handled = true;
                        break;
                }
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isLeftMouse = true;
                if (isFillMode)
                {
                    FloodFill(e.X, e.Y, drawPen.Color);
                    UpdatePictureBox();
                    SaveState();
                }
            }
            else if (e.Button == MouseButtons.Right)
            {
                isRightMouse = true;
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isLeftMouse = false;
                if (!isFillMode)
                {
                    SaveState();
                }
            }
            else if (e.Button == MouseButtons.Right)
            {
                isRightMouse = false;
                if (!isFillMode)
                {
                    SaveState();
                }
            }
            arrayPoints.ResetPoints();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isLeftMouse && !isRightMouse) return;
            if (isFillMode) return;

            arrayPoints.SetPoint(e.X, e.Y);
            if (arrayPoints.GetCountPoints() >= 2)
            {
                Pen currentPen = isLeftMouse ? drawPen : erasePen;
                graphics.DrawLines(currentPen, arrayPoints.GetPoints());
                UpdatePictureBox();
                arrayPoints.SetPoint(e.X, e.Y);
            }
        }

        private void FloodFill(int x, int y, Color fillColor)
        {
            if (x < 0 || x >= map.Width || y < 0 || y >= map.Height) return;

            Color targetColor = map.GetPixel(x, y);
            if (targetColor == fillColor) return;

            BitmapData data = map.LockBits(new Rectangle(0, 0, map.Width, map.Height), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
            int stride = data.Stride;
            int bytesPerPixel = 4;
            byte[] pixels = new byte[Math.Abs(stride) * map.Height];
            System.Runtime.InteropServices.Marshal.Copy(data.Scan0, pixels, 0, pixels.Length);

            Queue<Point> pixelsToFill = new Queue<Point>();
            pixelsToFill.Enqueue(new Point(x, y));

            while (pixelsToFill.Count > 0)
            {
                Point p = pixelsToFill.Dequeue();
                if (p.X < 0 || p.X >= map.Width || p.Y < 0 || p.Y >= map.Height) continue;

                int index = p.Y * stride + p.X * bytesPerPixel;
                if (index < 0 || index + 3 >= pixels.Length) continue;

                Color currentColor = Color.FromArgb(
                    pixels[index + 3],
                    pixels[index + 2],
                    pixels[index + 1],
                    pixels[index]);

                if (currentColor != targetColor) continue;

                pixels[index] = fillColor.B;
                pixels[index + 1] = fillColor.G;
                pixels[index + 2] = fillColor.R;
                pixels[index + 3] = fillColor.A;

                pixelsToFill.Enqueue(new Point(p.X + 1, p.Y));
                pixelsToFill.Enqueue(new Point(p.X - 1, p.Y));
                pixelsToFill.Enqueue(new Point(p.X, p.Y + 1));
                pixelsToFill.Enqueue(new Point(p.X, p.Y - 1));
            }

            System.Runtime.InteropServices.Marshal.Copy(pixels, 0, data.Scan0, pixels.Length);
            map.UnlockBits(data);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            drawPen.Color = ((Button)sender).BackColor;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                drawPen.Color = colorDialog1.Color;
                ((Button)sender).BackColor = colorDialog1.Color;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            graphics.Clear(pictureBox1.BackColor);
            UpdatePictureBox();
            SaveState();
        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            drawPen.Width = trackBar1.Value;
            erasePen.Width = trackBar1.Value;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "JPEG Image (*.jpg)|*.jpg|PNG Image (*.png)|*.png|Bitmap Image (*.bmp)|*.bmp|GIF Image (*.gif)|*.gif|TIFF Image (*.tiff)|*.tiff";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.DefaultExt = "png";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                if (pictureBox1.Image != null)
                {
                    try
                    {
                        ImageFormat format = ImageFormat.Png;
                        switch (saveFileDialog1.FilterIndex)
                        {
                            case 1: format = ImageFormat.Jpeg; break;
                            case 2: format = ImageFormat.Png; break;
                            case 3: format = ImageFormat.Bmp; break;
                            case 4: format = ImageFormat.Gif; break;
                            case 5: format = ImageFormat.Tiff; break;
                        }

                        if (format == ImageFormat.Jpeg)
                        {
                            EncoderParameters encoderParams = new EncoderParameters(1);
                            encoderParams.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 90L);
                            ImageCodecInfo jpegCodec = GetEncoderInfo("image/jpeg");
                            pictureBox1.Image.Save(saveFileDialog1.FileName, jpegCodec, encoderParams);
                        }
                        else
                        {
                            pictureBox1.Image.Save(saveFileDialog1.FileName, format);
                        }

                        MessageBox.Show("Изображение успешно сохранено!", "Сохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        isModified = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Нет изображения для сохранения!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private ImageCodecInfo GetEncoderInfo(string mimeType)
        {
            ImageCodecInfo[] codecs = ImageCodecInfo.GetImageEncoders();
            foreach (ImageCodecInfo codec in codecs)
            {
                if (codec.MimeType == mimeType)
                    return codec;
            }
            return null;
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            Color originalColor = drawPen.Color;
            int alpha = trackBar2.Value;
            Color newColor = Color.FromArgb(alpha, originalColor);
            drawPen.Color = newColor;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif;*.tiff";
            openFileDialog.Title = "Выберите изображение";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    Bitmap selectedImage = new Bitmap(openFileDialog.FileName);
                    Bitmap newMap = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
                    using (Graphics g = Graphics.FromImage(newMap))
                    {
                        g.DrawImage(selectedImage, 0, 0, newMap.Width, newMap.Height);
                    }
                    layers[currentLayerIndex] = newMap;
                    graphics.Dispose();
                    map = newMap;
                    graphics = Graphics.FromImage(map);
                    UpdatePictureBox();
                    SaveState();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при открытии изображения: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            isFillMode = !isFillMode;
            ((Button)sender).BackColor = isFillMode ? Color.LightGreen : SystemColors.Control;
        }

        private void pictureBox1_Resize(object sender, EventArgs e)
        {
            if (pictureBox1.Width > 0 && pictureBox1.Height > 0)
            {
                SetSize();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Проверяем, есть ли уже открытая Form2
            foreach (Form form in Application.OpenForms)
            {
                if (form is Form2)
                {
                    form.Focus(); // Если форма уже открыта, просто переключаемся на неё
                    return;
                }
            }

            // Если Form2 не открыта, создаем и показываем новую
            Form2 form2 = new Form2();
            form2.Show();

            // Не закрываем текущую Form1, чтобы можно было вернуться
            // this.Close(); - эту строку убираем
        }

        // Инициализация ComboBox с опциями
        private void InitializeComboBox()
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Добавить слой");
            comboBox1.Items.Add("Удалить слой");
            comboBox1.SelectedIndex = 0;
        }

        // Функция добавления нового слоя
        private void AddLayer()
        {
            if (layers.Count >= 3)
            {
                MessageBox.Show("Максимальное количество слоев - 3!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Bitmap newLayer = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            using (Graphics g = Graphics.FromImage(newLayer))
            {
                g.Clear(Color.Transparent);
            }
            layers.Add(newLayer);
            currentLayerIndex = layers.Count - 1;
            map = layers[currentLayerIndex];
            graphics = Graphics.FromImage(map);
            UpdateLayerList();
            UpdatePictureBox();
            SaveState();
        }

        // Функция удаления текущего слоя
        private void RemoveLayer()
        {
            if (layers.Count <= 1)
            {
                MessageBox.Show("Нельзя удалить единственный слой!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            layers[currentLayerIndex].Dispose();
            layers.RemoveAt(currentLayerIndex);
            currentLayerIndex = Math.Max(0, currentLayerIndex - 1);
            map = layers[currentLayerIndex];
            graphics = Graphics.FromImage(map);
            UpdateLayerList();
            UpdatePictureBox();
            SaveState();
        }

        // Обновление отображения слоев в ListBox
        private void UpdateLayerList()
        {
            listBox1.Items.Clear();
            for (int i = 0; i < layers.Count; i++)
            {
                listBox1.Items.Add($"Слой {i + 1}");
            }
            listBox1.SelectedIndex = currentLayerIndex;
        }

        // Обновление PictureBox для отображения всех слоев
        private void UpdatePictureBox()
        {
            Bitmap combined = new Bitmap(pictureBox1.ClientSize.Width, pictureBox1.ClientSize.Height);
            using (Graphics g = Graphics.FromImage(combined))
            {
                g.Clear(pictureBox1.BackColor);
                for (int i = 0; i < layers.Count; i++)
                {
                    g.DrawImage(layers[i], 0, 0);
                }
            }
            pictureBox1.Image = combined;
        }

        // Обработчик button15_Click для выполнения выбранной команды из ComboBox
        private void button15_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                string selectedOption = comboBox1.SelectedItem.ToString();
                switch (selectedOption)
                {
                    case "Добавить слой":
                        AddLayer();
                        break;
                    case "Удалить слой":
                        RemoveLayer();
                        break;
                    default:
                        MessageBox.Show("Выберите действие из списка!", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
        }
    }
}