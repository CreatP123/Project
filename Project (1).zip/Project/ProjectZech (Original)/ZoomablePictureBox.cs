﻿using System.Windows.Forms;

namespace ProjectZech
{
    internal class ZoomablePictureBox : Form
    {
    }
}